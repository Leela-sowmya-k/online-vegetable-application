package com.onlineVegitable.Test;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
class onlineVegetableApplicationTests {

	@Test
	void contextLoads() {
	}

}
