# Online_Vegetables
A platform for the convenience of people to buy groceries from home.
