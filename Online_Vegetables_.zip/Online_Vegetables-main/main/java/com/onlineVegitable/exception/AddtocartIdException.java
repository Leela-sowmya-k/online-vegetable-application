package com.onlineVegitable.exception;

public class AddtocartIdException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AddtocartIdException() {
		super();
	}
	public AddtocartIdException(String msg) {
		super(msg);
	}

}
