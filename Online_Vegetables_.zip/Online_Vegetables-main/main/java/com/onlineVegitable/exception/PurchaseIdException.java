package com.onlineVegitable.exception;

public class PurchaseIdException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public PurchaseIdException() {
		super();
	}
	public PurchaseIdException(String msg) {
		super(msg);
	}
	

}
