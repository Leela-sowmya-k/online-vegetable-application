package com.onlineVegitable.modal;

public class Admin {

}
