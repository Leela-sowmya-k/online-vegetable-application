package com.onlineVegitable.repository;

import org.springframework.data.repository.CrudRepository;


import com.onlineVegitable.modal.Feedback;
;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer>  {

	

}
