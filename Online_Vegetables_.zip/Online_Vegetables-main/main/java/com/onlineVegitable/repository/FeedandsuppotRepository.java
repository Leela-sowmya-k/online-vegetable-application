package com.onlineVegitable.repository;

import org.springframework.data.repository.CrudRepository;

import com.onlineVegitable.modal.Feedandsupport;
;

public interface FeedandsuppotRepository extends CrudRepository<Feedandsupport, Integer>  {

}
