package com.onlineVegitable.repository;

import org.springframework.data.repository.CrudRepository;

import com.onlineVegitable.modal.Customersupport;


public interface CustomersupportRepository extends CrudRepository<Customersupport, Integer>{

}