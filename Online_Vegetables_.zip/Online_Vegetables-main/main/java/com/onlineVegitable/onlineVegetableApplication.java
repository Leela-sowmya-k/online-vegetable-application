package com.onlineVegitable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class onlineVegetableApplication {

	public static void main(String[] args) {
		SpringApplication.run(onlineVegetableApplication.class, args);
	}

}
