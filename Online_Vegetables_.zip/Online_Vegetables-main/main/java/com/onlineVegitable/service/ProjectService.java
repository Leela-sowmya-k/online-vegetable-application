package com.onlineVegetable.service;

import com.onlineVegetable.modal.Project;

public interface ProjectService {
	public Project saveOrUpdate(Project project);
}
